#include <stdio.h>
#define print(a, b) printf("a와 b의 곱은 %d입니다\n", a * b);

int main() {
    print(2, 7);
}
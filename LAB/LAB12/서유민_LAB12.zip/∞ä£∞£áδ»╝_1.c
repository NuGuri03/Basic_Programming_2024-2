#include <stdio.h>

int main() {
    char *name = "서유민";
    char *major = "컴퓨터학부";

    printf("이름 : %s\n학과 : %s\n", name, major);
}